from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def get_inline_keyboard():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='Злоумышленники', callback_data='1/1')
    keyboard_builder.button(text='Виды угроз', callback_data='1/2')
    keyboard_builder.button(text='Способы защиты', callback_data='1/3')
    keyboard_builder.button(text='Другой вопрос', callback_data='3/3')
    keyboard_builder.button(text='Помощь', url = 'https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more_zlou():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='По местоположению', callback_data='3/1')
    keyboard_builder.button(text='По уровню ресурсов и возможностей', callback_data='3/2')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(1)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more_zlou_back():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='Назад', callback_data='1/1')
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more_ugrozy():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='По природе возникновения', callback_data='4/1')
    keyboard_builder.button(text='По источнику угрозы', callback_data='4/2')
    keyboard_builder.button(text='По способу воздействия', callback_data='4/3')
    keyboard_builder.button(text='По расположению источника', callback_data='4/4')
    keyboard_builder.button(text='По используемым средствам', callback_data='4/5')
    keyboard_builder.button(text='По степени воздействия на объект защиты', callback_data='4/6')
    keyboard_builder.button(text='По уровню квалификации и ресурсам источника', callback_data='4/7')
    keyboard_builder.button(text='Конкретные примеры угроз', callback_data='4/8')
    keyboard_builder.button(text='Ключевые документы ФСТЭК по вопросу', callback_data='4/9')
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(1)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more_ugrozy_back():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='Назад', callback_data='1/2')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')


def get_more_zach():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='По каким параметрам подбираются', callback_data='5/1')
    keyboard_builder.button(text='Организационные (организационно-правовые) меры защиты', callback_data='5/2')
    keyboard_builder.button(text='Технические (программно-аппаратные) меры защиты', callback_data='5/3')
    keyboard_builder.button(text='Основные принципы и подходы, подчеркиваемые ФСТЭК', callback_data='5/4')
    keyboard_builder.button(text='Конкретные требования', callback_data='5/5')
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(1)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more_zach_back():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='Назад', callback_data='1/3')
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Хочу задать более конкретный вопрос', callback_data='3/3')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more_back():
    keyboard_builder = InlineKeyboardBuilder()
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(1)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')