from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, KeyboardButtonPollType
from aiogram.utils.keyboard import ReplyKeyboardBuilder



def get_start_menu():
    keyboard_builder = ReplyKeyboardBuilder()
    keyboard_builder.button(text='Злоумышленники', callback_data='1/1')
    keyboard_builder.button(text='Виды угроз', callback_data='1/2')
    keyboard_builder.button(text='Способы защиты', callback_data='1/3')
    keyboard_builder.button(text='Другой вопрос', callback_data='1/4')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

def get_more():
    keyboard_builder = ReplyKeyboardBuilder()
    keyboard_builder.button(text='Вернутся в главное меню', callback_data='2/1')
    keyboard_builder.button(text='Помощь', url='https://t.me/Maestro_Alexandro')

    keyboard_builder.adjust(2)
    return keyboard_builder.as_markup(resize_keyboard=True, one_time_keyboard=True, input_field_placeholder='Выберите действие⬇')

