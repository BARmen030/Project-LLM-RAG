from aiogram import Bot, Dispatcher
import asyncio
import logging
from core.settings import settings
from aiogram.filters import Command, CommandStart
from aiogram import F, types
from core.utils.commands import set_commands
import asyncpg
from core.middlewares.dbmiddleware import DbSession
from datetime import datetime, timedelta
from core.handlers.basic import get_start, get_zlou, get_ugrozy, get_menu, get_zachita, get_mai, get_zlou_odin, get_zlou_dva
from core.handlers.basic import get_ugrozy_1, get_ugrozy_2, get_ugrozy_3, get_ugrozy_4, get_ugrozy_5, get_ugrozy_6, get_ugrozy_7
from core.handlers.basic import get_ugrozy_8, get_ugrozy_9, get_zachita_1, get_zachita_2, get_zachita_3, get_zachita_4, get_zachita_5
from core.handlers.basic import get_razr
from aiogram.types.callback_query import CallbackQuery
from aiogram.filters.callback_data import CallbackData
async def start_bot(bot: Bot):
    await set_commands(bot)
    await bot.send_message(settings.bots.admin_id, text='Бот запущен!')

async def stop_bot(bot: Bot):
    await bot.send_message(settings.bots.admin_id, text='Бот остановлен!')


async def creat_pool():
    return await asyncpg.create_pool(user="postgres", password='postgresalex', database='infobes',
                                             host='127.0.0.1', port=5432, command_timeout=60)

async def start():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s - [%(levelname)s] - %(name)s - "
                            "(%(filename)s).%(funcName)s(%(lineno)d) - %(message)s"

                        )
    bot = Bot(token=settings.bots.bot_token)
    pool_connect = await creat_pool()
    dp = Dispatcher()
    dp.update.middleware.register(DbSession(pool_connect))
    dp.startup.register(start_bot)
    dp.shutdown.register(stop_bot)
    dp.message.register(get_start, CommandStart())
    dp.message.register(get_start, F.text == "Привет!")
    dp.message.register(get_start, F.text == "Вернуться в главное меню")
    dp.message.register(get_zlou, F.text == "Злоумышленники")
    dp.callback_query.register(get_zlou, lambda c: c.data == '1/1')
    dp.callback_query.register(get_ugrozy, lambda c: c.data == '1/2')
    dp.callback_query.register(get_zachita, lambda c: c.data == '1/3')
    dp.callback_query.register(get_mai, lambda c: c.data == '1/4')
    dp.message.register(get_mai, F.text == "МАИ является КИИ?")
    dp.message.register(get_mai, F.text.contains("МАИ"))
    dp.callback_query.register(get_menu, lambda c: c.data == '2/1')
    dp.callback_query.register(get_mai, lambda c: c.data == '2/2')
    dp.callback_query.register(get_zlou_odin, lambda c: c.data == '3/1')
    dp.callback_query.register(get_zlou_dva, lambda c: c.data == '3/2')
    dp.callback_query.register(get_ugrozy_1, lambda c: c.data == '4/1')
    dp.callback_query.register(get_ugrozy_2, lambda c: c.data == '4/2')
    dp.callback_query.register(get_ugrozy_3, lambda c: c.data == '4/3')
    dp.callback_query.register(get_ugrozy_4, lambda c: c.data == '4/4')
    dp.callback_query.register(get_ugrozy_5, lambda c: c.data == '4/5')
    dp.callback_query.register(get_ugrozy_6, lambda c: c.data == '4/6')
    dp.callback_query.register(get_ugrozy_7, lambda c: c.data == '4/7')
    dp.callback_query.register(get_ugrozy_8, lambda c: c.data == '4/8')
    dp.callback_query.register(get_ugrozy_9, lambda c: c.data == '4/9')
    dp.callback_query.register(get_zachita_1, lambda c: c.data == '5/1')
    dp.callback_query.register(get_zachita_2, lambda c: c.data == '5/2')
    dp.callback_query.register(get_zachita_3, lambda c: c.data == '5/3')
    dp.callback_query.register(get_zachita_4, lambda c: c.data == '5/4')
    dp.callback_query.register(get_zachita_5, lambda c: c.data == '5/5')

    dp.callback_query.register(get_razr, lambda c: c.data == '3/3')

    try:
        await dp.start_polling(bot, allowed_updates=['message', 'callback_query'])
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(start())